package BOMJ_VALERA666.admintest;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Enderman;
import org.bukkit.entity.Player;
import org.bukkit.entity.minecart.RideableMinecart;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;
import org.jetbrains.annotations.NotNull;

public final class AdminTestPlugin extends org.bukkit.plugin.java.JavaPlugin implements Listener, CommandExecutor, TabCompleter {

	private static final String SUPPORTED_MOB = "enderman";
	private static final double MOVE_SPEED = 0.35D;
	private static final int PHASE_TICKS = 20;

	private final Map<UUID, ActiveTest> activeTests = new HashMap<>();

	@Override
	public void onEnable() {
		var command = this.getCommand("admintest");
		if (command != null) {
			command.setExecutor(this);
			command.setTabCompleter(this);
		}
		this.getServer().getPluginManager().registerEvents(this, this);
	}

	@Override
	public void onDisable() {
		activeTests.keySet().stream().toList().forEach(this::stopTest);
	}

	@Override
	public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
		if (!(sender instanceof Player player)) {
			sender.sendMessage("Only players can use this command.");
			return true;
		}

		if (args.length != 1 || !SUPPORTED_MOB.equalsIgnoreCase(args[0])) {
			player.sendMessage("Usage: /admintest enderman");
			return true;
		}

		startEndermanTest(player);
		player.sendMessage("Spawned an enderman admin test cart.");
		return true;
	}

	@Override
	public @NotNull List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command, @NotNull String alias, @NotNull String[] args) {
		if (args.length == 1) {
			return List.of(SUPPORTED_MOB);
		}
		return List.of();
	}

	@EventHandler
	public void onPlayerQuit(PlayerQuitEvent event) {
		stopTest(event.getPlayer().getUniqueId());
	}

	private void startEndermanTest(Player player) {
		stopTest(player.getUniqueId());

		Location spawnLocation = player.getLocation().clone();
		Vector initialDirection = flattened(player.getLocation().getDirection());
		if (initialDirection.lengthSquared() < 1.0E-6D) {
			initialDirection = new Vector(1, 0, 0);
		}
		spawnLocation.add(initialDirection.normalize().multiply(3.0D));
		spawnLocation.setPitch(0.0F);

		RideableMinecart cart = player.getWorld().spawn(spawnLocation, RideableMinecart.class, spawned -> {
			spawned.setInvisible(true);
			spawned.setInvulnerable(true);
			spawned.setSilent(true);
			spawned.setGravity(true);
			spawned.setMaxSpeed(0.8D);
			spawned.setSlowWhenEmpty(false);
			spawned.setPersistent(false);
		});

		Enderman enderman = player.getWorld().spawn(spawnLocation, Enderman.class, spawned -> {
			spawned.setAI(false);
			spawned.setAware(false);
			spawned.setInvulnerable(true);
			spawned.setSilent(true);
			spawned.setPersistent(false);
			spawned.setCollidable(false);
		});

		cart.addPassenger(enderman);

		BukkitTask task = new BukkitRunnable() {
			private boolean towardPlayer = true;
			private int phaseTick = 0;

			@Override
			public void run() {
				if (!player.isOnline() || player.isDead() || !cart.isValid() || !enderman.isValid() || player.getWorld() != cart.getWorld()) {
					stopTest(player.getUniqueId());
					return;
				}

				if (++phaseTick >= PHASE_TICKS) {
					phaseTick = 0;
					towardPlayer = !towardPlayer;
				}

				Vector direction = flattened(player.getLocation().toVector().subtract(cart.getLocation().toVector()));
				if (direction.lengthSquared() < 1.0E-6D) {
					direction = flattened(player.getLocation().getDirection());
				}
				if (direction.lengthSquared() < 1.0E-6D) {
					direction = new Vector(1, 0, 0);
				}

				direction.normalize();
				if (!towardPlayer) {
					direction.multiply(-1);
				}

				cart.setVelocity(direction.multiply(MOVE_SPEED));
				enderman.lookAt(player.getEyeLocation());
			}
		}.runTaskTimer(this, 0L, 1L);

		activeTests.put(player.getUniqueId(), new ActiveTest(cart, enderman, task));
	}

	private void stopTest(UUID playerId) {
		ActiveTest activeTest = activeTests.remove(playerId);
		if (activeTest == null) {
			return;
		}

		activeTest.task().cancel();
		if (activeTest.enderman().isValid()) {
			activeTest.enderman().remove();
		}
		if (activeTest.cart().isValid()) {
			activeTest.cart().remove();
		}
	}

	private static Vector flattened(Vector vector) {
		return vector.clone().setY(0);
	}

	private record ActiveTest(RideableMinecart cart, Enderman enderman, BukkitTask task) {
	}
}
